﻿using AchieversCPS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CPSFinal
{
    public partial class StudentHomePage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["userRole"].ToString() != "student")
            {
                Session["user"] = null;
                Response.Redirect("Login.aspx");
            }
            else
            {
                Users user = new Users();
                user = (Users)(Session["user"]);
                AchieversBL bl = new AchieversBL();
                List<Student> student = bl.getStudent(user.Userid);
                Student std = new Student();
                if(student.Count==1)
                {
                    foreach(Student stu in student)
                    {
                        std = stu;
                    }                  
                    Response.Write(std.StudentName+std.StudentId+std.StudentEmail+ std.Address+std.semester);
                }

            }
        }
    }
}