﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AchieversCPS
{
    public class Users
    {
        public string Userid { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }
    }
}
