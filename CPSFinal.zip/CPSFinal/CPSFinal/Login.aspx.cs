﻿using AchieversCPS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CPSFinal
{
    public partial class Login : System.Web.UI.Page
    {
        AchieversBL aBL = new AchieversBL();
        AchieversDAL aDAL = new AchieversDAL();
        List<Users> uList = new List<Users>();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            uList = aBL.GetAllUsers(txtUserName.Text, txtPassword.Text);
            if (uList.Count == 0)
            {
                Response.Write("InvalidUser!!");
            }
            else if (uList.Count == 1)
            {
                Users user = new Users();
                foreach (Users u in uList)
                {
                    user = u;
                }
                Session["user"] = user;
                Session["userRole"] = user.Role;
                Session["userId"] = user.Userid;
                Response.Redirect("~\\StudentHomePage.aspx");
            }
            

        }

        protected void btnReset_Click(object sender, EventArgs e)
        {

        }
    }
}