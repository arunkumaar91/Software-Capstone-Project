﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace AchieversCPS
{
    public class AchieversDAL
    {
        List<Users> allUsers = new List<Users>();
        SqlConnection conn1 = new SqlConnection(@"Data Source=mssql6.gear.host;Initial Catalog=eservices;Persist Security Info=True;User ID=eservices;Password=Zu5S~!EB8jQq");
        SqlConnection conn2 = new SqlConnection(@"");
        public List<Users> GetAllUsers(string usernumber, string password)
        {
            try
            {
                conn1.Open();

                SqlCommand selectCommand = new SqlCommand("dbo.uspGetUser",conn1);
                selectCommand.CommandType = CommandType.StoredProcedure;
                selectCommand.Parameters.AddWithValue("@ipvUserId", usernumber);
                selectCommand.Parameters.AddWithValue("@ipvPass", password);
                SqlDataReader reader = selectCommand.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Users user = new Users();
                        user.Userid= reader["userId"].ToString();
                        user.Password = reader["pass"].ToString();
                        user.Role = reader["roleOfperson"].ToString();
                        allUsers.Add(user);
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (conn1.State == ConnectionState.Open)
                {
                    conn1.Close();
                }
            }
            return allUsers;
        }
        
        public List<Student> GetStudent(string studentId)
        {
            List<Student> studentList =new List<Student>();
            try
            {
                conn1.Open();

                SqlCommand selectCommand = new SqlCommand("dbo.uspGetStudent", conn1);
                selectCommand.CommandType = CommandType.StoredProcedure;
                selectCommand.Parameters.AddWithValue("@ipvUserId", studentId);
                SqlDataReader reader = selectCommand.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Student student = new Student();
                        student.StudentId = (int)reader["studentId"];
                        student.StudentName = reader["studentFirstName"].ToString()+reader["studentLastName"].ToString();
                        student.ProgramName=reader["programName"].ToString();
                        student.Address=reader["resAddress"].ToString();
                        student.contactNumber=reader["contactNumber"].ToString();
                        student.degreeType = reader["degreetype"].ToString();
                        student.FacultyAdvisor=reader["facultyAdvisor"].ToString();
                        student.gender=reader["gender"].ToString();
                        student.semester=reader["semester"].ToString();
                        student.StartYear = (DateTime)reader["startYear"];
                        student.StudentDOB = reader["dateOfBirth"].ToString();
                        student.StudentEmail=reader["uhclEmail"].ToString();                        
                        studentList.Add(student);
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (conn1.State == ConnectionState.Open)
                {
                    conn1.Close();
                }
            }
            return studentList;
        }

    }
}