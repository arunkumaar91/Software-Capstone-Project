﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;



namespace AchieversCPS
{
    public class AchieversBL
    {
       
        List<Users> userList = new List<Users>();
        public List<Users> GetAllUsers(string userid,string password)
        {
            AchieversDAL dal = new AchieversDAL();
            userList = dal.GetAllUsers(userid,password);
            return userList;
        }

        public List<Student> getStudent(string userId)
        {
            List<Student> student=new List<Student>();
            AchieversDAL dal = new AchieversDAL();
            student = dal.GetStudent(userId);
            return student;
        }
    }
}