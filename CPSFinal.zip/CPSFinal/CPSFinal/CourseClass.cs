﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CPSFinal
{
    public class CourseClass
    {
        public int courseNumber { get; set; }
        public string courseRubric { get; set; }
        public string className { get; set; }
        public int units { get; set; }
        public Boolean Mandatory { get; set; }
        public int MandatedYear { get; set; }
    }
}